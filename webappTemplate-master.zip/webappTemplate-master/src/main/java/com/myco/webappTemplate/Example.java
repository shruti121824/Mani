package com.myco.webappTemplate;

public class Example {
	public int add(int a, int b) {
		return a + b;
	}

}
